def add_numbers(num1 , num2):
    return num1 + num2


def subtract_numbers(num1, num2):
    return num1 - num2

def multiply_numbers(num1, num2):
    return num1 * num2

def divide_numbers(num1, num2):
    return num1 / num2

def mean(a):
    return sum(a) / len(a)

def listfind_odd(a):
    return [x for x in a if x % 2 == 1]

def listfing_even(a):
    return [x for x in a if x % 2 == 0]


